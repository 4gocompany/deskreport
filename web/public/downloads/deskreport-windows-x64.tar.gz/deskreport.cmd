@echo off
node "%~dp0deskreport-client.mjs" %*
