#!/bin/sh
exec "$HOME/.deskreport/bin/deskreport" --widget
